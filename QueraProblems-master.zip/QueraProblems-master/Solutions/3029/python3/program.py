x1, y1 = map(int, input().split())
x2, y2 = map(int, input().split())

if x2 > x1:
    print("Right")
else:
    print("Left")
