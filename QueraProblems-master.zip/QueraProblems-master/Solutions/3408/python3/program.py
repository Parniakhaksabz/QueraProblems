_ = input()
words = input().split()

result = reversed(words)
print(*result)
