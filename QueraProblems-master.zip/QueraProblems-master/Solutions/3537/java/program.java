// Copy from Quera

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        System.out.print("W");
        for (int i = 0; i < n; i++)
            System.out.print("o");
        System.out.println("w!");
    }
}
