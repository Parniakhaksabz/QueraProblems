// Copy from Quera

#include <iostream>
using namespace std;

int main()
{
    int k;
    cin >> k;
    cout << k * (k + 1) / 2 << '\n';
    return 0;
}