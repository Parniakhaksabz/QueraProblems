k = int(input())

result = (k * (k + 1)) // 2

print(result)
