// Copy from Quera

#include <iostream>
using namespace std;
int main()
{
    int n;
    cin >> n;
    cout << "W";
    for (int i = 0; i < n; i++)
    {
        cout << "o";
    }
    cout << "w!";
    return 0;
}