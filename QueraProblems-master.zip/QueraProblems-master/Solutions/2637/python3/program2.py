n = int(input())

# (n+1)//2 = ceiling(n/2)
result = (n//2+1)*((n+1)//2+1)

print(result)
