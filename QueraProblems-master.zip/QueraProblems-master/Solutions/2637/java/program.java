// Copy from Quera

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=scanner.nextInt();
        System.out.println((n/2+1)*((n+1)/2+1));
        /*
        age mikhaim saghfe x/y ke x va y adad haie tabiei hstn ro hsb konim,
        mitonim kharej ghesmate taghsime (x+y-1)/y ro dr nzr bgirim
        */
    }
}
