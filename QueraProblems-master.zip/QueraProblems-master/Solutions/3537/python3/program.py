num_of_repeat = int(input())

result = "W" + ("o" * num_of_repeat) + "w!"

print(result)
