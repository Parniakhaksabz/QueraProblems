// 2018-06-24

#include <iostream>

using namespace std;

int main()
{
	int number;
	cin >> number;
	cout << "W";
	for (int i = 0; i < number; i++)
		cout << "o";
	cout << "w!";
	return 0;
}