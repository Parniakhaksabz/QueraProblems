// Copy from Quera

#include <iostream>
using namespace std;
int main()
{
    int x, y, x1, y1;
    cin >> x >> y >> x1 >> y1;
    if (x < x1)
        cout << "Right";
    else
        cout << "Left";
    return 0;
}