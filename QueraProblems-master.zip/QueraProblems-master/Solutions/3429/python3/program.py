temperature = int(input())

if temperature > 100:
    print("Steam")
elif temperature < 0:
    print("Ice")
else:
    print("Water")
